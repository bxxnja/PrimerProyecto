package com.anfp.anfp.controller;
import com.anfp.anfp.model.Cliente;
import com.anfp.anfp.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")

public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @PostMapping
    public Cliente crearcliente(@RequestBody Cliente cliente){
        return clienteService.crearCliente(cliente);
    }
    @GetMapping
    public List<Cliente> obtenerclientees(){
        return clienteService.obtenerClientes();
    }

    //cliente controller
    @GetMapping("/buscar/{run}")
    public Cliente buscarPorRun(@PathVariable String run){
        return clienteService.buscarPorRun(run)
            .orElseThrow(() -> new RuntimeException("cliente no encontrado con run" +  run));
    }

    //metodo eliminar por rut 
    @DeleteMapping("/eliminar/{run}")
    public ResponseEntity<String> eliminarCliente(@PathVariable String run){
        return ResponseEntity.status(HttpStatus.NO_CONTENT)
            .body("cliente eliminado con run " + run);
    }

    //metodo actualizar por rut
    /**
     * @param run
     * @param clienteActualizado
     * @return
     */
    @PutMapping("/actulizar/{run}")
    public ResponseEntity<Cliente> actualizarCliente(@PathVariable String run, @RequestBody Cliente clienteActualizado){
      try{
        Cliente actualizado = clienteService.actualizarCliente(run, clienteActualizado);
        return ResponseEntity.ok(actualizado);

      }catch (RuntimeException e ){
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
      } 
    }

        


}

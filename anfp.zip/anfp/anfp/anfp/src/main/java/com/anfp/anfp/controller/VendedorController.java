package com.anfp.anfp.controller;

import com.anfp.anfp.model.Vendedor;
import com.anfp.anfp.service.VendedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vendedores")

public class VendedorController {

    @Autowired
    private VendedorService vendedorService;

    @PostMapping
    public Vendedor crearVendedor(@RequestBody Vendedor vendedor){
        return vendedorService.crearVendedor(vendedor);
    }
    @GetMapping
    public List<Vendedor> obtenervendedores(){
        return vendedorService.obtenerVendedores();
    }

    //vendedor controller
    @GetMapping("/buscar/{run}")
    public Vendedor buscarPorRun(@PathVariable String run){
        return vendedorService.buscarPorRun(run)
            .orElseThrow(() -> new RuntimeException("vendedor no encontrado con run" +  run));
    }

    //metodo eliminar por rut 
    @DeleteMapping("/eliminar/{run}")
    public ResponseEntity<String> eliminarvendedor(@PathVariable String run){
        return ResponseEntity.status(HttpStatus.NO_CONTENT)
            .body("vendedor eliminado con run " + run);
    }

    //metodo actualizar por rut
    /**
     * @param run
     * @param vendedorActualizado
     * @return
     */
    @PutMapping("/actulizar/{run}")
    public ResponseEntity<Vendedor> actualizarvendedor(@PathVariable String run, @RequestBody Vendedor vendedorActualizado){
      try{
        Vendedor actualizado = vendedorService.actualizarVendedor(run, vendedorActualizado);
        return ResponseEntity.ok(actualizado);

      }catch (RuntimeException e ){
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
      } 
    }
    













}

package com.anfp.anfp.controller;

import com.anfp.anfp.model.Producto;
import com.anfp.anfp.service.ProductoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // GET /api/productos
    @GetMapping
    public List<Producto> obtenerInventario(@RequestParam(required = false) String nombre) {
        if (nombre != null && !nombre.isBlank()) {
            return productoService.buscarPorNombre(nombre);
        } else {
            return productoService.obtenerTodos();
        }
    }

    // POST /api/productos
    @PostMapping
    public Producto agregarProducto(@RequestBody Producto producto) {
        return productoService.guardarProducto(producto);
    }
}

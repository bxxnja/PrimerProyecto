package com.anfp.anfp.service;

import com.anfp.anfp.model.Envio;

import java.util.List;

public interface EnvioService {
    Envio crearEnvio(Envio envio);
    void eliminarEnvio(Integer id);
    Envio actualizarEstado(Integer id, String nuevoEstado);
    List<Envio> obtenerTodos();
}

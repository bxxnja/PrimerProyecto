package com.anfp.anfp.service;

import com.anfp.anfp.model.Cliente;
import com.anfp.anfp.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class ClienteService {


    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente crearCliente(Cliente cliente){
        return clienteRepository.save(cliente);
    }

    public List<Cliente> obtenerClientes(){
        return clienteRepository.findAll();
    }
    //buscar por rut
    public Optional<Cliente> buscarPorRun(String run){
        return clienteRepository.findByRun(run);
    }

    //elimnar por rut
    public void eliminarClientePorRun(String run){
        Optional<Cliente> cliente  = clienteRepository.findByRun(run);
        cliente.ifPresent(clienteRepository::delete);
    
    }
    //actualizar por rut
    public Cliente actualizarCliente(String run, Cliente clienteActualizado){
        Cliente clienteExistente = clienteRepository.findByRun(run)
            .orElseThrow(() -> new RuntimeException("cliente no encontrado con run" + run));
        clienteExistente.setNombre(clienteActualizado.getNombre());
        clienteExistente.setApellido(clienteActualizado.getApellido());
        clienteExistente.setFechaNacimiento(clienteActualizado.getFechaNacimiento());
        clienteExistente.setCorreo(clienteActualizado.getCorreo());


        return clienteRepository.save(clienteExistente);
        
    }

}

package com.anfp.anfp.service;

import com.anfp.anfp.model.Producto;

import java.util.List;

public interface ProductoService {
    List<Producto> obtenerTodos();
    List<Producto> buscarPorNombre(String nombre);
    Producto guardarProducto(Producto producto);
}
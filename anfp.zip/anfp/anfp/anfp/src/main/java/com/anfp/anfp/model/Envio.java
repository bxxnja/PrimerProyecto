package com.anfp.anfp.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "envio")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String direccion;

    private String ciudad;

    private String estado; // Ej: "En preparación", "Enviado", "Entregado"
}

package com.anfp.anfp.repository;

import com.anfp.anfp.model.Envio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvioRepository extends JpaRepository<Envio, Integer> {
}

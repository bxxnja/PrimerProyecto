package com.anfp.anfp.service;


import com.anfp.anfp.model.Vendedor;
import com.anfp.anfp.repository.VendedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Controller
public class VendedorService {


    @Autowired
    private VendedorRepository vendedorRepository;

    public Vendedor crearVendedor(Vendedor vendedor){
        return vendedorRepository.save(vendedor);
    }

    public List<Vendedor> obtenerVendedores(){
        return vendedorRepository.findAll();
    }
    //buscar por rut
    public Optional<Vendedor> buscarPorRun(String run){
        return vendedorRepository.findByRun(run);
    }

    //elimnar por rut
    public void eliminarVendedorPorRun(String run){
        Optional<Vendedor> vendedor  = vendedorRepository.findByRun(run);
        vendedor.ifPresent(vendedorRepository::delete);
    
    }
    //actualizar por rut
    public Vendedor actualizarVendedor(String run, Vendedor vendedorActualizado){
        Vendedor vendedorExistente = vendedorRepository.findByRun(run)
            .orElseThrow(() -> new RuntimeException("vendedor no encontrado con run" + run));
        vendedorExistente.setNombre(vendedorActualizado.getNombre());
        vendedorExistente.setApellido(vendedorActualizado.getApellido());
        vendedorExistente.setFechaNacimiento(vendedorActualizado.getFechaNacimiento());
        vendedorExistente.setCorreo(vendedorActualizado.getCorreo());
        vendedorExistente.setClub(vendedorActualizado.getClub());

        return vendedorRepository.save(vendedorExistente);
        
    }

}
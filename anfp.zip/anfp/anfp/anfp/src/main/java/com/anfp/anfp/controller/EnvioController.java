package com.anfp.anfp.controller;

import com.anfp.anfp.model.Envio;
import com.anfp.anfp.service.EnvioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/envios")
@CrossOrigin
public class EnvioController {

    private final EnvioService envioService;

    public EnvioController(EnvioService envioService) {
        this.envioService = envioService;
    }

    @PostMapping
    public Envio crearEnvio(@RequestBody Envio envio) {
        return envioService.crearEnvio(envio);
    }

    @DeleteMapping("/{id}")
    public void eliminarEnvio(@PathVariable Integer id) {
        envioService.eliminarEnvio(id);
    }

    @PutMapping("/{id}/estado")
    public Envio actualizarEstado(@PathVariable Integer id, @RequestBody String nuevoEstado) {
        return envioService.actualizarEstado(id, nuevoEstado);
    }

    @GetMapping
    public List<Envio> listarEnvios() {
        return envioService.obtenerTodos();
    }
}

package com.anfp.anfp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnfpApplicationTests {

	@Test
	void contextLoads() {
	}

}
